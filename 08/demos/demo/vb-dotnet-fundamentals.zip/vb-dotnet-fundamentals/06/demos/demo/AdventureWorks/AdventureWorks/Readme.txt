﻿AdventureWorks WPF Sample
=========================================

- Add \Xml folder and Products.xml and Customers.xml
- Add CustomerListControl.xaml and ProductListControl.xaml

- Build AdventureWorks.Data Layer
- Build AdventureWorks.ViewModel Layer
