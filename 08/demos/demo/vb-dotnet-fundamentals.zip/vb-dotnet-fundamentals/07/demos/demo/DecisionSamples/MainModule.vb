﻿Module MainModule

  Sub Main()
    CaseSample02()
  End Sub

#Region "Looping Methods"
  Sub LoopingSample01()
    Dim sample As New LoopingSample()

    sample.Sample01()

    Console.ReadKey()
  End Sub
  Sub LoopingSample02()
    Dim sample As New LoopingSample()

    sample.Sample02()

    Console.ReadKey()
  End Sub
  Sub LoopingSample03()
    Dim sample As New LoopingSample()

    sample.Sample03()

    Console.ReadKey()
  End Sub
  Sub LoopingSample04()
    Dim sample As New LoopingSample()

    sample.Sample04()

    Console.ReadKey()
  End Sub
  Sub LoopingSample05()
    Dim sample As New LoopingSample()

    sample.Sample05()

    Console.ReadKey()
  End Sub
  Sub LoopingSample06()
    Dim sample As New LoopingSample()

    sample.Sample06()

    Console.ReadKey()
  End Sub
#End Region

#Region "If Statement Methods"
  Sub IfSample01()
    Dim sample As New IfSample()

    sample.Sample01()

    Console.ReadKey()
  End Sub
  Sub IfSample02()
    Dim sample As New IfSample()

    sample.Sample02()

    Console.ReadKey()
  End Sub
  Sub IfSample03()
    Dim sample As New IfSample()

    sample.Sample03()

    Console.ReadKey()
  End Sub
#End Region

#Region "Case Statement Methods"
  Sub CaseSample01()
    Dim sample As New CaseSample()

    sample.Sample01()

    Console.ReadKey()
  End Sub
  Sub CaseSample02()
    Dim sample As New CaseSample()

    sample.Sample02()

    Console.ReadKey()
  End Sub
#End Region
End Module
