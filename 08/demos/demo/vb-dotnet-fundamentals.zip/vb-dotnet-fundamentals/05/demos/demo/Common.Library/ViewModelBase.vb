﻿Public Class ViewModelBase
  Inherits CommonBase

End Class
