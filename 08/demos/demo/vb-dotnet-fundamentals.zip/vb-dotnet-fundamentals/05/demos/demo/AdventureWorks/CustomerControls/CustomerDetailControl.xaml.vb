﻿Public Class CustomerDetailControl

End Class
