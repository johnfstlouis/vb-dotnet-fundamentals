﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Variables Operators and Constants")>
<Assembly: AssemblyDescription("Variables Operators and Constants")>
<Assembly: AssemblyCompany("Paul D. Sheriff Consulting")>
<Assembly: AssemblyProduct("Variables Operators and Constants")>
<Assembly: AssemblyCopyright("Copyright © 2019 by Paul D. Sheriff Consulting")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("ebc998ea-c79f-40b3-b10f-6317fcfadd06")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
