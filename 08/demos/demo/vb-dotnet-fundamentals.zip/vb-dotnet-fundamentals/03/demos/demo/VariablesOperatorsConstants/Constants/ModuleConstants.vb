﻿Module ModuleConstants
  Public Const DEFAULT_ACTIVE As Boolean = True
    Public Const DEFAULT_LIST_PRICE As Decimal = 999.99D
End Module
